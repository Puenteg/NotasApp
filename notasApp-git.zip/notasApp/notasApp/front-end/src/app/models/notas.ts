export class Nota{
    _id?: number;
    nombre: string;
    descripcion: string;
    fecha: Date;

    constructor(_id: number, nombre: string, descripcion: string, fecha: Date){
        this._id = _id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fecha = fecha;
    }
}