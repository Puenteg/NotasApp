import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NotasServicesService } from '../../services/notas-services.service';
import { Nota } from '../../models/notas';

@Component({
  selector: 'app-crear-notas',
  standalone: false,
  
  templateUrl: './crear-notas.component.html',
  styleUrl: './crear-notas.component.css'
})
export class CrearNotasComponent {
  notasForm: FormGroup;

  constructor(
    private fb: FormBuilder, 
    private _notaService: NotasServicesService
  ){
    this.notasForm = this.fb.group({
      nota: [''],
      descripcion: [''],
      fecha: ['']
    })
  }

    ngOnInit(): void{
    this.agregarNota();
  }

  
  agregarNota(){
    const NOTA: Nota ={
      nombre: this.notasForm.get('nota')?.value,
      descripcion: this.notasForm.get('descripcion')?.value,
      fecha: this.notasForm.get('fecha')?.value,
    }
    console.log(NOTA);
    
    this._notaService.guardarNota(NOTA).subscribe(data =>{
      console.log("Se creo correctamente");
    }, error =>{
      console.log("Ya todo esta valiendo vergaaa <|:,{o");
      console.log(error);
    })
  }
}
