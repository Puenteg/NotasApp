import { Component } from '@angular/core';
import { Nota } from '../../models/notas';
import { NotasServicesService } from '../../services/notas-services.service';
import { response } from 'express';

@Component({
  selector: 'app-listar-notas',
  standalone: false,
  templateUrl: './listar-notas.component.html',
  styleUrl: './listar-notas.component.css'
})
export class ListarNotasComponent {
  listNotas: Nota[] = [];

  constructor(private _notaService: NotasServicesService){
  }

  ngOnInit(): void{
    this.obtenerNotas();
  }

  obtenerNotas(){
    
    this._notaService.getNotas().subscribe(data =>{
      this.listNotas = data;
      console.log(data);
    }, error =>{
      console.log(error);
    })
  }

  deleteNota(id: any): void{
    this._notaService.eliminarNota(id).subscribe(response =>{
      console.log("Eliminado con exito :D", response);
      this.obtenerNotas();
    }, error =>{
      console.log("Valio verga padrino :c", error);
    })
  } 
}
