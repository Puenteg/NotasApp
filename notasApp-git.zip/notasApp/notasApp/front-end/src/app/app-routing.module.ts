import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListarNotasComponent } from './components/listar-notas/listar-notas.component';
import { CrearNotasComponent } from './components/crear-notas/crear-notas.component';

const routes: Routes = [
    { path: '', component: ListarNotasComponent},
    { path: 'crear-nota', component: CrearNotasComponent},
    { path: 'editar-nota/:id', component: CrearNotasComponent},
    { path: '**', redirectTo: '', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
