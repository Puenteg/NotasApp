import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Nota } from '../models/notas';

@Injectable({
  providedIn: 'root'
})
export class NotasServicesService {
  
  url = 'http://localhost:9000/api/notas';
  constructor(private http: HttpClient) { }

  getNotas(): Observable<any>{
    return this.http.get(this.url);
  }
  
  eliminarNota(id: string): Observable<any>{
    return this.http.delete(this.url + id);
  }

  guardarNota(nota: Nota): Observable<any>{
    return this.http.post(this.url, nota);
  }
}
