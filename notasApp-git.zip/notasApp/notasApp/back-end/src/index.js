const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

require("dotenv").config();

const app = express();
const port = process.env.PORT || 3000;

const notasRoutes = require("./routes/notas");

//  MODELWARES
app.use(express.json());
app.use('/api', notasRoutes);
app.use(cors());

//  ROUTES 
app.get("/", (req, res) => {
    res.send("Wellcome to my API")
});

//  CONEXIÓN A MONGODB
mongoose
    .connect(process.env.MONGODB_URI)
    .then(()=> console.log('Conectado a MongoDB Altas'))
    .catch((error)=> console.error(error));


app.listen(port, ()=> console.log('Servidor en el puerto', port));