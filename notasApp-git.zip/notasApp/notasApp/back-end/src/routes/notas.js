const express = require("express");
const notasSchema = require("../models/notas");

const router = express.Router();

//  ENDPOINT
router.post("/notas", (req, res) => {
    const nota = notasSchema(req.body);
    nota
        .save()
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
});

router.get("/notas", (req, res) => {
    notasSchema
        .find()
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
});

router.get("/notas/:id", (req, res) => {
    const { id } = req.params;
    notasSchema
        .findById(id)
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
});

router.put("/notas/:id", (req, res) => {
    const { id } = req.params;
    const { nombre, descripcion, fecha } = req.body;
    notasSchema
        .updateOne({ _id: id }, { $set: { nombre, descripcion, fecha } })
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
});

router.delete("/notas/:id", (req, res) => {
    const { id } = req.params;
    notasSchema
        .deleteOne({ _id: id })
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
    
});

/* router.delete('/notas/:id', async (req, res) => {
  try {
    const result = await Product.deleteOne({ _id: req.params.id });
    if (result.deletedCount === 0) {
      return res.status(404).send({ message: 'Nota no encontrada' });
    }
    res.status(200).send({ message: 'Nota eliminada' });
  } catch (error) {
    res.status(500).send(error);
  }
}); */
module.exports = router;