const mongoose = require("mongoose");

const notasSchema = mongoose.Schema({
    nombre: {
        type: String,
        require: true
    },
    descripcion: {
        type: String,
        require: true
    },
    fecha: {
        type: Date
    }
});

module.exports = mongoose.model('Nota', notasSchema);