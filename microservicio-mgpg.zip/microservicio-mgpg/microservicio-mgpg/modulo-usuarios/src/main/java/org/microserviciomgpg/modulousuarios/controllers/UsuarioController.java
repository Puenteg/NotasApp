package org.microserviciomgpg.modulousuarios.controllers;

import jakarta.validation.Valid;
import org.microserviciomgpg.modulousuarios.models.entity.Usuario;
import org.microserviciomgpg.modulousuarios.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController

public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    public List<Usuario> listar(){
        return usuarioService.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> detalle(@PathVariable Long id){
        Optional<Usuario> usuarioOptional = usuarioService.buscarPorId(id);
        if (usuarioOptional.isPresent()){
            return ResponseEntity.ok(usuarioOptional.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody Usuario usuario, BindingResult result){
        if(result.hasErrors()){
            return validar(result);
        }
        if(!usuario.getEmail().isEmpty() && usuarioService.existeEmail(usuario.getEmail())){
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", "Ya existe un usuario"));
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.guardar(usuario));
    }

    private static ResponseEntity<Map<String, String>> validar(BindingResult result) {
        Map<String, String> errores = new HashMap<>();
        result.getFieldErrors().forEach(error -> errores.put(error.getField(), "El campo "+error.getField()+" " +error.getDefaultMessage()));
        return ResponseEntity.badRequest().body(errores);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editar(@Valid @RequestBody Usuario usuario, @PathVariable Long id, BindingResult result){
        if(result.hasErrors()){
            return validar(result);
        }
        Optional<Usuario> usuarioOptional = usuarioService.buscarPorId(id);
        if(usuarioOptional.isPresent()){
            Usuario usuarioBd = usuarioOptional.orElseThrow();
            if(!usuario.getEmail().isEmpty() && !usuario.getEmail().equalsIgnoreCase(usuarioBd.getEmail()) && usuarioService.buscarPorEmail(usuario.getEmail()).isPresent()){
                return ResponseEntity.badRequest().body(Collections.singletonMap("error", "Ya existe un usuario con ese email"));
            }

            usuarioBd.setNombre(usuario.getNombre());
            usuarioBd.setEmail(usuario.getEmail());
            usuarioBd.setPassword(usuario.getPassword());
            return  ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.guardar(usuarioBd));
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        Optional<Usuario> usuarioOptional = usuarioService.buscarPorId(id);
        if(usuarioOptional.isPresent()){
            usuarioService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/usuarios-por-asignatura")
    public ResponseEntity<?> listarUsuariosPorAsignatura(@RequestParam List<Long> ids){
        return ResponseEntity.ok(usuarioService.listarPorUsuarioId(ids));
    }

}