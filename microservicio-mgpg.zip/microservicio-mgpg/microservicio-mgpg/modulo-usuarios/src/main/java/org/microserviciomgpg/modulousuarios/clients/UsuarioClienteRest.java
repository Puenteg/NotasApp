package org.microserviciomgpg.modulousuarios.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "modulo-asignaturas", url="modulo-asignaturas:9191")
public interface UsuarioClienteRest {

    @DeleteMapping("/eliminar-asignatura-usuario/{id}")
    void eliminarAsignaturaCursoPorId(@PathVariable Long id);

}
