package org.microserviciomgpg.moduloasignaturas.services;

import org.microserviciomgpg.moduloasignaturas.models.Usuario;
import org.microserviciomgpg.moduloasignaturas.models.entities.Asignatura;

import java.util.List;
import java.util.Optional;

public interface AsignaturaService {

    List<Asignatura> listar();
    Optional<Asignatura> buscarPorId(Long id);
    Asignatura guardar(Asignatura asignatura);
    void eliminar(Long id);

    Optional<Usuario> asignarUsuario(Usuario usuario, Long AsignaturaId);
    Optional<Usuario> crearUsuario(Usuario usuario, Long AsignaturaId);
    Optional<Usuario> eliminarUsuario(Usuario usuario, Long AsignaturaId);

    void eliminarAsignaturaUsuario(Long id);

}
