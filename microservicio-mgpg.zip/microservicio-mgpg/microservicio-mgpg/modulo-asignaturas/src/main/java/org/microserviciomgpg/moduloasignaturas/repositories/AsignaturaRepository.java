package org.microserviciomgpg.moduloasignaturas.repositories;

import org.microserviciomgpg.moduloasignaturas.models.entities.Asignatura;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface AsignaturaRepository extends CrudRepository<Asignatura, Long> {

    @Modifying
    @Query("DELETE FROM AsignaturaUsuario WHERE usuarioId = ?1")
    void eliminarAsignaturaUsuario(Long id);

}
