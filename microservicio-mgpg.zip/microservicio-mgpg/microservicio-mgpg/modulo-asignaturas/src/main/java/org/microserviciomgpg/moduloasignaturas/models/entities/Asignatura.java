package org.microserviciomgpg.moduloasignaturas.models.entities;

import jakarta.persistence.*;
import org.microserviciomgpg.moduloasignaturas.models.Usuario;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "asignatura")
public class Asignatura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private float calificacion;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "asignatura_id")
    private List<AsignaturaUsuario> asignaturasUsuario;

    @Transient
    private List<Usuario> usuarios;

    public Asignatura() {
        asignaturasUsuario = new ArrayList<>();
        usuarios = new ArrayList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }

    public List<AsignaturaUsuario> getAsignaturasUsuario() {
        return asignaturasUsuario;
    }

    public void setAsignaturasUsuario(List<AsignaturaUsuario> asignaturasUsuario) {
        this.asignaturasUsuario = asignaturasUsuario;
    }

    public void addAsignatura(AsignaturaUsuario asignaturaUsuario) {
        asignaturasUsuario.add(asignaturaUsuario);
    }

    public void removeAsignatura(AsignaturaUsuario asignaturaUsuario) {
        asignaturasUsuario.remove(asignaturaUsuario);
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }
}
