package org.microserviciomgpg.moduloasignaturas.clients;

import org.microserviciomgpg.moduloasignaturas.models.Usuario;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "modulo-usuarios", url = "modulo-usuarios:9090")
public interface UsuarioClientRest {
    @GetMapping("/{id}")
    Usuario buscarPorId(@PathVariable Long id);

    @PostMapping
    Usuario guardar(@RequestBody Usuario usuario);

    @GetMapping ("/usuarios-por-asignatura")
    List<Usuario> listarUsuariosPorAsigatura(@RequestParam Iterable<Long> ids);

}
