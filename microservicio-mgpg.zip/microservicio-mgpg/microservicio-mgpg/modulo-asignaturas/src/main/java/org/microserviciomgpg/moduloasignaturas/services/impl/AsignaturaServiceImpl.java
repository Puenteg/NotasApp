package org.microserviciomgpg.moduloasignaturas.services.impl;

import org.microserviciomgpg.moduloasignaturas.clients.UsuarioClientRest;
import org.microserviciomgpg.moduloasignaturas.models.Usuario;
import org.microserviciomgpg.moduloasignaturas.models.entities.Asignatura;
import org.microserviciomgpg.moduloasignaturas.models.entities.AsignaturaUsuario;
import org.microserviciomgpg.moduloasignaturas.repositories.AsignaturaRepository;
import org.microserviciomgpg.moduloasignaturas.services.AsignaturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class AsignaturaServiceImpl implements AsignaturaService {

    @Autowired
    private AsignaturaRepository asignaturaRepository;

    @Autowired
    private UsuarioClientRest cliente;

    @Override
    @Transactional(readOnly = true)
    public List<Asignatura> listar() {
        return (List<Asignatura>) asignaturaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Asignatura> buscarPorId(Long id) {
        return asignaturaRepository.findById(id);
    }

    @Override
    @Transactional
    public Asignatura guardar(Asignatura asignatura) {
        return asignaturaRepository.save(asignatura);
    }

    @Override
    public void eliminar(Long id) {
        asignaturaRepository.deleteById(id);
    }

    @Override
    @Transactional
    public Optional<Usuario> asignarUsuario(Usuario usuario, Long asignaturaId) {
        Optional<Asignatura> asignaturaOptional = asignaturaRepository.findById(asignaturaId);
        if (asignaturaOptional.isPresent()) {
            Usuario usuarioCliente = cliente.buscarPorId(usuario.getId());

            Asignatura asignatura = asignaturaOptional.get();

            AsignaturaUsuario asignaturaUsuario =  new AsignaturaUsuario();
            asignaturaUsuario.setUsuarioId(usuarioCliente.getId());

            asignatura.addAsignatura(asignaturaUsuario);
            asignaturaRepository.save(asignatura);
            return Optional.of(usuarioCliente);
        }
        return Optional.empty();
    }

    @Override
    @Transactional
    public Optional<Usuario> crearUsuario(Usuario usuario, Long asignaturaId) {
        Optional <Asignatura> asignaturaOptional = asignaturaRepository.findById(asignaturaId);
        if (asignaturaOptional.isPresent()) {
            Usuario usuarioCliente =  cliente.guardar(usuario);

            Asignatura asignatura = asignaturaOptional.orElseThrow();

            AsignaturaUsuario asignaturaUsuario = new AsignaturaUsuario();
            asignaturaUsuario.setUsuarioId(usuarioCliente.getId());

            asignatura.addAsignatura(asignaturaUsuario);
            asignaturaRepository.save(asignatura);
            return Optional.of(usuarioCliente);

        }
        return Optional.empty();

    }

    @Override
    @Transactional
    public Optional<Usuario> eliminarUsuario(Usuario usuario, Long asignaturaId) {
        Optional <Asignatura> asignaturaOptional = asignaturaRepository.findById(asignaturaId);
        if (asignaturaOptional.isPresent()) {
            Usuario usuarioCliente =  cliente.buscarPorId(usuario.getId());

            Asignatura asignatura = asignaturaOptional.orElseThrow();

            AsignaturaUsuario asignaturaUsuario = new AsignaturaUsuario();
            asignaturaUsuario.setUsuarioId(usuarioCliente.getId());

            asignatura.removeAsignatura(asignaturaUsuario);
            asignaturaRepository.save(asignatura);
            return Optional.of(usuarioCliente);
        }
        return Optional.empty();
    }

    @Override
    @Transactional
    public void eliminarAsignaturaUsuario(Long id) {
        asignaturaRepository.eliminarAsignaturaUsuario(id);
    }

}