package org.microserviciomgpg.moduloasignaturas.controllers;

import feign.FeignException;
import jakarta.validation.Valid;
import org.microserviciomgpg.moduloasignaturas.models.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.microserviciomgpg.moduloasignaturas.models.entities.Asignatura;
import org.microserviciomgpg.moduloasignaturas.services.AsignaturaService;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class AsignaturaController {
    @Autowired
    private AsignaturaService asignaturaService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return ResponseEntity.ok(asignaturaService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id){
        Optional<Asignatura> asignaturaOptional = asignaturaService.buscarPorId(id);
        if (asignaturaOptional.isPresent()){
            return ResponseEntity.ok(asignaturaOptional.orElseThrow());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<?> guardar( @RequestBody Asignatura asignatura){
        Asignatura asignaturaBd = asignaturaService.guardar(asignatura);
        return ResponseEntity.status(HttpStatus.CREATED).body(asignaturaBd);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editar(@RequestBody Asignatura asignatura, @PathVariable Long id){
        Optional<Asignatura> asignaturaOptional = asignaturaService.buscarPorId(id);
        if (asignaturaOptional.isPresent()){
            Asignatura asignaturaBd = asignaturaOptional.orElseThrow();
            asignaturaBd.setNombre(asignatura.getNombre());
            asignaturaBd.setCalificacion(asignatura.getCalificacion());
            return ResponseEntity.status(HttpStatus.CREATED).body(asignaturaService.guardar(asignaturaBd));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        Optional<Asignatura> asignaturaOptional = asignaturaService.buscarPorId(id);
        if(asignaturaOptional.isPresent()){
            asignaturaService.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/asignar-usuario/{asignaturaId}")
    public ResponseEntity<?> asignarUsuario(@RequestBody Usuario usuario, @PathVariable Long asignaturaId){
        Optional<Usuario> usuarioOptional;
        try{
            usuarioOptional = asignaturaService.asignarUsuario(usuario, asignaturaId);
        }catch (FeignException e){
            return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("error ", "No existe el usuario" + "o un problema con el microservicio de usuarios" + e.getMessage()));
        }
        if (usuarioOptional.isPresent()){
            return ResponseEntity.status(HttpStatus.CREATED).body(usuarioOptional.get());
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping ("/crear-usuario/{asignaturaId}")
    public ResponseEntity<?> crearUsuario(@RequestBody Usuario usuario, @PathVariable Long asignaturaId){
        Optional<Usuario> usuarioOptional;
        try{
            usuarioOptional = asignaturaService.crearUsuario(usuario, asignaturaId);
        }catch (FeignException e){
            return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("error ", "No se creo el usuario" + "o un problema con el microservicio de usuarios" + e.getMessage()));
        }
        if (usuarioOptional.isPresent()){
            return ResponseEntity.status(HttpStatus.CREATED).body(usuarioOptional.get());
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/desasignar-usuario/{asignaturaId}")
    public ResponseEntity<?> desasignarUsuario(@RequestBody Usuario usuario, @PathVariable Long asignaturaId){
        Optional<Usuario> usuarioOptional;
        try{
            usuarioOptional = asignaturaService.eliminarUsuario(usuario, asignaturaId);
        }catch (FeignException e){
            return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("error ", "No se elimino el usuario" + "o un problema con el microservicio de usuarios" + e.getMessage()));
        }
        if (usuarioOptional.isPresent()){
            return ResponseEntity.status(HttpStatus.OK).body(usuarioOptional.get());
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/eliminar-asignatura-usuario/{id}")
    public ResponseEntity<?> eliminarAsignauraUsuario(@PathVariable Long id){
        asignaturaService.eliminarAsignaturaUsuario(id);
        return ResponseEntity.noContent().build();

    }

}

